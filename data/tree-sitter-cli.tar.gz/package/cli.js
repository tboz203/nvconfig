#!/usr/bin/env node

const path = require('path');
const spawn = require("child_process").spawn;
const executable = 'tree-sitter';
spawn(
  path.join(__dirname, executable),
  process.argv.slice(2),
  { stdio: 'inherit' }
).on('close', process.exit)
